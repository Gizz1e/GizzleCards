import { defineConfig } from 'tsup';

export default defineConfig({
  entry: ['src/server/index.ts'],
  format: ['cjs'],
  platform: 'node',
  target: 'node18',
  outDir: 'dist/server',
  sourcemap: true,
  clean: true,
  splitting: false,
  dts: false,
  outExtension() {
    return { js: '.cjs' };
  },
});
