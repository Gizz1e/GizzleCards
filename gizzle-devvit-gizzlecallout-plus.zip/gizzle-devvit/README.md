# GIZZLE (Devvit Web)

A Devvit Web card game inspired by UNO — renamed **GIZZLE**.

## Rules implemented

- Up to **2 tables**, each table supports **2–4 players**.
- Uses an UNO-like deck (numbers + Skip/Reverse/Draw 2 + Wild/Wild Draw 4).
- **Stacking**:
  - **Draw 2 stacks only on Draw 2**
  - **Draw 4 stacks only on Draw 4**
  - No mixing Draw2/Draw4 stacks
- Penalty draw (stack total) ends your turn.
- Reverse behaves like Skip when there are 2 players.

### Draw 4 fairness

- A **Draw 4** is only legal if you have **no card matching the current color**.

### GIZZLE callout

- If you play a card and end that play with **exactly 1 card**, a **GIZZLE callout** becomes pending.
- You must press **GIZZLE!** before the next player takes an action.
- Any other seated player can press **Catch GIZZLE** before that action to apply a penalty: **you draw 2**.

### Quality-of-life

- **Rematch** button after a game finishes (host only): resets back to lobby while keeping players seated.
- **Spectator-friendly**: if you aren't seated, the UI shows Spectating and lets you Join during lobby.
- Smoother UI micro-animations (turn pulse, discard flip, penalty shake, GIZZLE overlays) with reduced-motion support.
- Keyboard shortcuts (table view): **D**=Draw, **P**=Pass, **G**=Call GIZZLE, **C**=Catch GIZZLE, **R**=Start/Rematch.
- Optional optimistic concurrency: action requests include the last-seen `version`; stale requests return **409** and the client auto-syncs.

## Development

### Prereqs

- Node.js 22 (recommended)
- Devvit CLI installed and logged in

### Run

```bash
npm install
npm run dev
```

This runs:
- Vite build in watch mode → `dist/client`
- Tsup build in watch mode → `dist/server/index.cjs`
- `devvit playtest`

### Build

```bash
npm run build
```

### Launch

The official guide uses `npx devvit upload` and `npx devvit publish`:

```bash
npm run launch
```

## Notes

- Client API endpoints are under `/api/...`.
- Server bundle is **CommonJS** (`dist/server/index.cjs`) as required by Devvit Web.
