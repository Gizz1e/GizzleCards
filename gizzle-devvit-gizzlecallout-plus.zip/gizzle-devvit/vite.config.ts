import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

// Vite builds the WebView client bundle that Devvit serves from `post.dir`.
export default defineConfig({
  root: path.resolve(__dirname, 'src/client'),
  plugins: [react()],
  build: {
    outDir: path.resolve(__dirname, 'dist/client'),
    emptyOutDir: true,
    sourcemap: true,
  },
});
