import express from 'express';
import { createServer, getServerPort, realtime, context } from '@devvit/web/server';
import type { Color, PublicTableState, TableSummary, TableState } from '../shared/types';
import {
  applyDraw,
  applyPass,
  applyPlay,
  applyGizzleCall,
  applyGizzleCatch,
  applyRematch,
  dealAndStart,
  playableCardsForPlayer,
  removePlayer,
} from './game';
import { getAllTables, getTable, setTable } from './storage';

function getUserId(): string {
  const c: any = context;
  return c.userId ?? c.user?.id ?? 'anon';
}

function getUserName(): string {
  const c: any = context;
  return c.userName ?? c.username ?? c.user?.name ?? `user-${String(getUserId()).slice(0, 6)}`;
}

function topCardLabel(t: TableState): string | null {
  const top = t.discard[t.discard.length - 1];
  if (!top) return null;
  const color = (t.currentColor ?? top.color) ? String(t.currentColor ?? top.color).toUpperCase() : 'WILD';
  return `${color} ${top.label}`;
}

function winnerName(t: TableState): string | null {
  if (!t.winnerId) return null;
  return t.players.find((p) => p.id === t.winnerId)?.name ?? 'Unknown';
}

function publicState(t: TableState, viewerId: string): PublicTableState {
  const you = t.players.find((p) => p.id === viewerId) ?? null;
  const cur = t.players[t.currentTurn] ?? null;
  const playable = you ? playableCardsForPlayer(t, viewerId) : [];

  const canStart = t.phase === 'lobby' && t.hostId === viewerId && t.players.length >= 2;
  const isTurn = t.phase === 'playing' && cur?.id === viewerId;

  const canDraw = t.phase === 'playing' && isTurn && !!you && (
    (t.pendingDraw !== null) || (!you.hasDrawn)
  );

  const canPass = t.phase === 'playing' && isTurn && !!you && t.pendingDraw === null && you.hasDrawn;

  const canCallGizzle =
    t.phase === 'playing' &&
    !!you &&
    !!t.gizzlePending &&
    t.gizzlePending.playerId === viewerId &&
    you.hand.length === 1;

  const canCatchGizzle =
    t.phase === 'playing' &&
    !!you &&
    !!t.gizzlePending &&
    t.gizzlePending.playerId !== viewerId;

  const canRematch = t.phase === 'finished' && t.hostId === viewerId && t.players.length >= 2;

  return {
    tableId: t.tableId,
    phase: t.phase,
    hostId: t.hostId,
    players: t.players.map((p) => ({ id: p.id, name: p.name, handCount: p.hand.length })),
    currentColor: t.currentColor,
    topCardLabel: topCardLabel(t),
    pendingDraw: t.pendingDraw,
    gizzlePending: t.gizzlePending,
    currentPlayerId: cur?.id ?? null,
    currentPlayerName: cur?.name ?? null,
    you: you ? { id: you.id, name: you.name, handCount: you.hand.length } : null,
    yourHand: you ? you.hand : [],
    playableCardIds: playable,
    canDraw,
    canPass,
    canCallGizzle,
    canCatchGizzle,
    canStart,
    canRematch,
    winnerName: winnerName(t),

    version: t.version,
    updatedAt: t.updatedAt,
  };
}

/**
 * Optional optimistic concurrency guard.
 * If the client includes expectedVersion and it doesn't match current, we reject.
 */
function assertFresh(t: TableState, expectedVersion: unknown): void {
  if (expectedVersion === undefined || expectedVersion === null) return;
  const n = Number(expectedVersion);
  if (!Number.isFinite(n)) return;
  if (n !== t.version) {
    const err: any = new Error('Stale state — please refresh');
    err.code = 'STALE_STATE';
    throw err;
  }
}

async function broadcast(tableId: number) {
  const c: any = context;
  const postId = c.postId ?? 'unknown-post';
  const channel = `gizzle-${postId}-table-${tableId}`;
  await realtime.send({
    channel,
    data: { type: 'table-updated', tableId },
  });
}

const app = express();
app.use(express.json());

// Lobby summary for two tables
app.get('/api/lobby', async (_req, res) => {
  try {
    const tables = await getAllTables();
    const out: TableSummary[] = tables.map((t) => ({
      tableId: t.tableId,
      phase: t.phase,
      playerCount: t.players.length,
      currentColor: t.currentColor,
      topCardLabel: t.phase === 'playing' || t.phase === 'finished' ? topCardLabel(t) : null,
      winnerName: t.phase === 'finished' ? winnerName(t) : null,

      version: t.version,
      updatedAt: t.updatedAt,
    }));
    res.json({ tables: out });
  } catch (e: any) {
    res.status(500).json({ error: e.message ?? String(e) });
  }
});

// Get full table state (sanitized)
app.get('/api/table/state', async (req, res) => {
  try {
    const tableId = Number(req.query.tableId);
    const t = await getTable(tableId);
    res.json(publicState(t, getUserId()));
  } catch (e: any) {
    const status = e?.code === 'STALE_STATE' ? 409 : 400;
    res.status(status).json({ error: e.message ?? String(e) });
  }
});

app.post('/api/table/join', async (req, res) => {
  try {
    const tableId = Number(req.body?.tableId);
    const t = await getTable(tableId);
    const uid = getUserId();
    const name = getUserName();

    if (t.players.some((p) => p.id === uid)) {
      res.json({ ok: true });
      return;
    }

    if (t.phase !== 'lobby') {
      res.status(400).json({ error: 'Game already started' });
      return;
    }
    if (t.players.length >= 4) {
      res.status(400).json({ error: 'Table is full' });
      return;
    }

    t.players.push({ id: uid, name, hand: [], hasDrawn: false });
    if (!t.hostId) t.hostId = uid;

    await setTable(tableId, t);
    await broadcast(tableId);

    res.json({ ok: true });
  } catch (e: any) {
    const status = e?.code === 'STALE_STATE' ? 409 : 400;
    res.status(status).json({ error: e.message ?? String(e) });
  }
});

app.post('/api/table/leave', async (req, res) => {
  try {
    const tableId = Number(req.body?.tableId);
    const expectedVersion = req.body?.expectedVersion;
    const t = await getTable(tableId);
    assertFresh(t, expectedVersion);
    removePlayer(t, getUserId());
    await setTable(tableId, t);
    await broadcast(tableId);
    res.json({ ok: true });
  } catch (e: any) {
    const status = e?.code === 'STALE_STATE' ? 409 : 400;
    res.status(status).json({ error: e.message ?? String(e) });
  }
});

app.post('/api/table/start', async (req, res) => {
  try {
    const tableId = Number(req.body?.tableId);
    const expectedVersion = req.body?.expectedVersion;
    const t = await getTable(tableId);
    assertFresh(t, expectedVersion);
    const uid = getUserId();
    if (t.hostId !== uid) {
      res.status(403).json({ error: 'Only the host can start' });
      return;
    }
    if (t.phase !== 'lobby') {
      res.status(400).json({ error: 'Already started' });
      return;
    }

    dealAndStart(t);
    await setTable(tableId, t);
    await broadcast(tableId);

    res.json({ ok: true });
  } catch (e: any) {
    const status = e?.code === 'STALE_STATE' ? 409 : 400;
    res.status(status).json({ error: e.message ?? String(e) });
  }
});

app.post('/api/table/play', async (req, res) => {
  try {
    const tableId = Number(req.body?.tableId);
    const cardId = String(req.body?.cardId ?? '');
    const chooseColor = (req.body?.chooseColor as Color | undefined) ?? undefined;
    const expectedVersion = req.body?.expectedVersion;

    const t = await getTable(tableId);
    assertFresh(t, expectedVersion);
    applyPlay(t, getUserId(), cardId, chooseColor);

    await setTable(tableId, t);
    await broadcast(tableId);

    res.json({ ok: true });
  } catch (e: any) {
    const status = e?.code === 'STALE_STATE' ? 409 : 400;
    res.status(status).json({ error: e.message ?? String(e) });
  }
});

app.post('/api/table/draw', async (req, res) => {
  try {
    const tableId = Number(req.body?.tableId);
    const t = await getTable(tableId);
    assertFresh(t, req.body?.expectedVersion);
    applyDraw(t, getUserId());
    await setTable(tableId, t);
    await broadcast(tableId);
    res.json({ ok: true });
  } catch (e: any) {
    const status = e?.code === 'STALE_STATE' ? 409 : 400;
    res.status(status).json({ error: e.message ?? String(e) });
  }
});

app.post('/api/table/pass', async (req, res) => {
  try {
    const tableId = Number(req.body?.tableId);
    const t = await getTable(tableId);
    assertFresh(t, req.body?.expectedVersion);
    applyPass(t, getUserId());
    await setTable(tableId, t);
    await broadcast(tableId);
    res.json({ ok: true });
  } catch (e: any) {
    const status = e?.code === 'STALE_STATE' ? 409 : 400;
    res.status(status).json({ error: e.message ?? String(e) });
  }
});

// GIZZLE callout: the target player calls (clears pending)
app.post('/api/table/gizzle/call', async (req, res) => {
  try {
    const tableId = Number(req.body?.tableId);
    const t = await getTable(tableId);
    assertFresh(t, req.body?.expectedVersion);
    applyGizzleCall(t, getUserId());
    await setTable(tableId, t);
    await broadcast(tableId);
    res.json({ ok: true });
  } catch (e: any) {
    const status = e?.code === 'STALE_STATE' ? 409 : 400;
    res.status(status).json({ error: e.message ?? String(e) });
  }
});

// GIZZLE callout: any other seated player can catch before the next action; target draws 2
app.post('/api/table/gizzle/catch', async (req, res) => {
  try {
    const tableId = Number(req.body?.tableId);
    const t = await getTable(tableId);
    assertFresh(t, req.body?.expectedVersion);
    applyGizzleCatch(t, getUserId());
    await setTable(tableId, t);
    await broadcast(tableId);
    res.json({ ok: true });
  } catch (e: any) {
    const status = e?.code === 'STALE_STATE' ? 409 : 400;
    res.status(status).json({ error: e.message ?? String(e) });
  }
});

// Rematch: resets the table back to lobby while keeping the same players (host only)
app.post('/api/table/rematch', async (req, res) => {
  try {
    const tableId = Number(req.body?.tableId);
    const t = await getTable(tableId);
    assertFresh(t, req.body?.expectedVersion);
    applyRematch(t, getUserId());
    await setTable(tableId, t);
    await broadcast(tableId);
    res.json({ ok: true });
  } catch (e: any) {
    const status = e?.code === 'STALE_STATE' ? 409 : 400;
    res.status(status).json({ error: e.message ?? String(e) });
  }
});

// Boot the Devvit Web server wrapper
const server = createServer(app);
app.listen(getServerPort(), () => {
  // eslint-disable-next-line no-console
  console.log(`GIZZLE server listening on ${getServerPort()}`);
});

export default server;
