import { redis, context } from '@devvit/web/server';
import type { TableState } from '../shared/types';

const TABLE_COUNT = 2;

function keyFor(tableId: number): string {
  const postId = (context as any).postId ?? 'unknown-post';
  return `gizzle:${postId}:table:${tableId}`;
}

export function emptyTable(tableId: number): TableState {
  return {
    tableId,
    phase: 'lobby',
    hostId: null,
    players: [],
    deck: [],
    discard: [],
    currentColor: null,
    currentTurn: 0,
    direction: 1,
    pendingDraw: null,
    gizzlePending: null,
    winnerId: null,
    version: 1,
    updatedAt: Date.now(),
  };
}

export async function getTable(tableId: number): Promise<TableState> {
  if (tableId < 0 || tableId >= TABLE_COUNT) throw new Error('Invalid table');
  const key = keyFor(tableId);
  const raw = await redis.get(key);
  if (!raw) {
    const t = emptyTable(tableId);
    await redis.set(key, JSON.stringify(t));
    return t;
  }
  return JSON.parse(String(raw)) as TableState;
}

export async function setTable(tableId: number, state: TableState): Promise<void> {
  const key = keyFor(tableId);
  state.version += 1;
  state.updatedAt = Date.now();
  await redis.set(key, JSON.stringify(state));
}

export async function getAllTables(): Promise<TableState[]> {
  const out: TableState[] = [];
  for (let i = 0; i < TABLE_COUNT; i++) out.push(await getTable(i));
  return out;
}
