import type { Card, CardKind, Color, PendingDraw, Player, TableState, GizzlePending } from '../shared/types';

function rngId(prefix: string, n: number) {
  return `${prefix}-${n}-${Math.random().toString(36).slice(2, 10)}`;
}

function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function makeDeck(): Card[] {
  let idx = 0;
  const colors: Color[] = ['red', 'yellow', 'green', 'blue'];
  const deck: Card[] = [];

  for (const color of colors) {
    // 0 once, 1-9 twice
    deck.push({ id: rngId('c', idx++), kind: 'N', color, value: 0, label: '0' });
    for (let v = 1; v <= 9; v++) {
      deck.push({ id: rngId('c', idx++), kind: 'N', color, value: v, label: String(v) });
      deck.push({ id: rngId('c', idx++), kind: 'N', color, value: v, label: String(v) });
    }

    // actions: Skip, Reverse, Draw2 (two each)
    const addAction = (kind: CardKind, label: string) => {
      deck.push({ id: rngId('c', idx++), kind, color, value: null, label });
      deck.push({ id: rngId('c', idx++), kind, color, value: null, label });
    };
    addAction('S', 'SKIP');
    addAction('R', 'REVERSE');
    addAction('D2', 'DRAW 2');
  }

  for (let i = 0; i < 4; i++) {
    deck.push({ id: rngId('w', idx++), kind: 'W', color: null, value: null, label: 'WILD' });
    deck.push({ id: rngId('w', idx++), kind: 'D4', color: null, value: null, label: 'DRAW 4' });
  }

  return shuffle(deck);
}

function isMatch(card: Card, top: Card, currentColor: Color | null): boolean {
  if (card.kind === 'W' || card.kind === 'D4') return true;

  const color = card.color;
  const topColor = currentColor ?? top.color;

  if (color && topColor && color === topColor) return true;

  // number match
  if (card.kind === 'N' && top.kind === 'N' && card.value === top.value) return true;

  // symbol match
  if (card.kind !== 'N' && top.kind !== 'N' && card.kind === top.kind) return true;

  return false;
}

export function playableCardsForPlayer(state: TableState, playerId: string): string[] {
  const p = state.players.find((x) => x.id === playerId);
  if (!p) return [];
  if (state.phase !== 'playing') return [];
  if (state.players[state.currentTurn]?.id !== playerId) return [];

  const top = state.discard[state.discard.length - 1];
  if (!top) return [];

  // Pending draw stacking: only same type can be stacked, no mixing.
  if (state.pendingDraw) {
    const allowedKind = state.pendingDraw.type;
    return p.hand.filter((c) => c.kind === allowedKind).map((c) => c.id);
  }

  return p.hand
    .filter((c, idx) => {
      if (!isMatch(c, top, state.currentColor)) return false;

      // Keep client highlights consistent with server-side legality:
      // Draw 4 can be restricted when the player still has a card matching the current color.
      if (c.kind === 'D4' && state.currentColor) {
        const hasMatchingColor = p.hand.some((o, j) => j !== idx && o.color === state.currentColor);
        if (hasMatchingColor) return false;
      }

      return true;
    })
    .map((c) => c.id);
}

function drawOne(state: TableState): Card {
  if (state.deck.length === 0) {
    // reshuffle discard (keep top)
    if (state.discard.length <= 1) {
      // Rare edge case: all remaining cards are in players' hands and only the top discard remains.
      // We rebuild a fresh deck but KEEP the top discard card so gameplay doesn't "forget" it.
      const top = state.discard[state.discard.length - 1];
      const rebuilt = makeDeck();
      // Remove the exact card id if present to avoid duplicating the visible top card.
      state.deck = rebuilt.filter((c) => !top || c.id !== top.id);
      state.discard = top ? [top] : [];
    } else {
      const top = state.discard[state.discard.length - 1];
      const rest = state.discard.slice(0, -1);
      state.deck = shuffle(rest);
      state.discard = [top];
    }
  }
  const c = state.deck.shift();
  if (!c) throw new Error('Deck is empty');
  return c;
}

export function dealAndStart(state: TableState): void {
  if (state.players.length < 2 || state.players.length > 4) {
    throw new Error('Need 2-4 players to start');
  }

  state.phase = 'playing';
  state.pendingDraw = null;
  state.gizzlePending = null;
  state.direction = 1;
  state.currentTurn = 0;
  state.winnerId = null;

  // fresh deck and hands
  state.deck = makeDeck();
  state.discard = [];
  for (const p of state.players) {
    p.hand = [];
    p.hasDrawn = false;
    for (let i = 0; i < 7; i++) p.hand.push(drawOne(state));
  }

  // Flip a starting card that is a number (keeps first turn simple)
  let starter: Card;
  while (true) {
    starter = drawOne(state);
    if (starter.kind === 'N' && starter.color) break;
    // put aside non-number starters into discard shuffle pool
    state.discard.push(starter);
  }
  state.discard.push(starter);
  state.currentColor = starter.color;
}

function expireGizzleIfNeeded(state: TableState, actorId: string): void {
  // If a "GIZZLE" callout is pending for someone else, it expires as soon as the next player takes an action.
  // (Others had the window to catch before this action.)
  if (state.gizzlePending && state.gizzlePending.playerId !== actorId) {
    state.gizzlePending = null;
  }
}

function setGizzlePendingIfNeeded(state: TableState, player: Player): void {
  // Only when the player ends their play at exactly 1 card.
  if (player.hand.length === 1) {
    const pending: GizzlePending = {
      playerId: player.id,
      playerName: player.name,
      createdAt: Date.now(),
    };
    state.gizzlePending = pending;
  } else if (state.gizzlePending?.playerId === player.id) {
    // If they no longer have 1 card, clear any pending callout.
    state.gizzlePending = null;
  }
}

function nextIndex(state: TableState, steps = 1): number {
  const n = state.players.length;
  let idx = state.currentTurn;
  for (let i = 0; i < steps; i++) {
    idx = (idx + state.direction + n) % n;
  }
  return idx;
}

function advanceTurn(state: TableState, steps = 1): void {
  if (state.players.length === 0) return;
  state.currentTurn = nextIndex(state, steps);
  // reset draw flag for whoever's now current
  const cur = state.players[state.currentTurn];
  if (cur) cur.hasDrawn = false;
}

export function applyPlay(
  state: TableState,
  playerId: string,
  cardId: string,
  chooseColor?: Color
): void {
  if (state.phase !== 'playing') throw new Error('Game is not playing');
  const cur = state.players[state.currentTurn];
  if (!cur || cur.id !== playerId) throw new Error('Not your turn');

  expireGizzleIfNeeded(state, playerId);

  const cardIdx = cur.hand.findIndex((c) => c.id === cardId);
  if (cardIdx === -1) throw new Error('Card not in your hand');

  const card = cur.hand[cardIdx];
  const playable = playableCardsForPlayer(state, playerId);
  if (!playable.includes(cardId)) throw new Error('Card not playable');

  // Optional fairness rule (common house rule / close to classic UNO):
  // Wild Draw Four is only legal when you have no card matching the current color.
  // This check only applies when no draw penalty is pending.
  if (!state.pendingDraw && card.kind === 'D4' && state.currentColor) {
    const hasMatchingColor = cur.hand.some((c, i) => i !== cardIdx && c.color === state.currentColor);
    if (hasMatchingColor) {
      throw new Error('Draw 4 is only legal when you have no card matching the current color');
    }
  }

  // Remove from hand
  cur.hand.splice(cardIdx, 1);
  cur.hasDrawn = false;

  // Place on discard
  state.discard.push(card);

  // Update color
  if (card.kind === 'W' || card.kind === 'D4') {
    if (!chooseColor) throw new Error('Must choose a color');
    state.currentColor = chooseColor;
  } else {
    state.currentColor = card.color;
  }

  // If last card, win immediately
  if (cur.hand.length === 0) {
    state.gizzlePending = null;
    state.phase = 'finished';
    state.winnerId = cur.id;
    return;
  }

  // If the player is down to one card, they must call GIZZLE.
  setGizzlePendingIfNeeded(state, cur);

  // Handle effects
  if (card.kind === 'S') {
    advanceTurn(state, 2);
    return;
  }

  if (card.kind === 'R') {
    state.direction = (state.direction === 1 ? -1 : 1);
    // With 2 players, reverse acts like skip
    if (state.players.length === 2) {
      advanceTurn(state, 2);
    } else {
      advanceTurn(state, 1);
    }
    return;
  }

  if (card.kind === 'D2') {
    const pending: PendingDraw = state.pendingDraw ?? { type: 'D2', count: 0 };
    if (pending.type !== 'D2') {
      // no mixing
      throw new Error('Cannot stack Draw 2 on Draw 4');
    }
    pending.count += 2;
    state.pendingDraw = pending;
    advanceTurn(state, 1);
    return;
  }

  if (card.kind === 'D4') {
    const pending: PendingDraw = state.pendingDraw ?? { type: 'D4', count: 0 };
    if (pending.type !== 'D4') {
      // no mixing
      throw new Error('Cannot stack Draw 4 on Draw 2');
    }
    pending.count += 4;
    state.pendingDraw = pending;
    advanceTurn(state, 1);
    return;
  }

  // Wild has no other effect
  advanceTurn(state, 1);
}

export function applyDraw(state: TableState, playerId: string): void {
  if (state.phase !== 'playing') throw new Error('Game is not playing');
  const cur = state.players[state.currentTurn];
  if (!cur || cur.id !== playerId) throw new Error('Not your turn');

  expireGizzleIfNeeded(state, playerId);

  if (state.pendingDraw) {
    const n = state.pendingDraw.count;
    for (let i = 0; i < n; i++) {
      cur.hand.push(drawOne(state));
    }
    state.pendingDraw = null;
    // penalty draw ends your turn
    advanceTurn(state, 1);
    return;
  }

  if (cur.hasDrawn) throw new Error('You already drew this turn');

  cur.hand.push(drawOne(state));
  cur.hasDrawn = true;

  // If you draw (normal draw), you obviously have >1 card; clear pending if it was you (safety).
  if (state.gizzlePending?.playerId === playerId) state.gizzlePending = null;
}

export function applyPass(state: TableState, playerId: string): void {
  if (state.phase !== 'playing') throw new Error('Game is not playing');
  const cur = state.players[state.currentTurn];
  if (!cur || cur.id !== playerId) throw new Error('Not your turn');

  expireGizzleIfNeeded(state, playerId);
  if (state.pendingDraw) throw new Error('You must draw the penalty or stack');
  if (!cur.hasDrawn) throw new Error('You must draw before passing');

  advanceTurn(state, 1);
}

export function applyGizzleCall(state: TableState, playerId: string): void {
  if (state.phase !== 'playing') throw new Error('Game is not playing');
  if (!state.gizzlePending) throw new Error('No GIZZLE callout is pending');
  if (state.gizzlePending.playerId !== playerId) throw new Error('Only the target player can call GIZZLE');

  const p = state.players.find((x) => x.id === playerId);
  if (!p) throw new Error('You are not seated');
  if (p.hand.length !== 1) throw new Error('You can only call GIZZLE when you have exactly one card');

  state.gizzlePending = null;
}

export function applyGizzleCatch(state: TableState, catcherId: string): void {
  if (state.phase !== 'playing') throw new Error('Game is not playing');
  if (!state.gizzlePending) throw new Error('No GIZZLE callout to catch');

  const catcher = state.players.find((x) => x.id === catcherId);
  if (!catcher) throw new Error('You are not seated');
  if (catcherId === state.gizzlePending.playerId) throw new Error('You cannot catch yourself');

  const target = state.players.find((x) => x.id === state.gizzlePending!.playerId);
  if (!target) {
    state.gizzlePending = null;
    throw new Error('Target player is no longer seated');
  }
  if (target.hand.length !== 1) {
    state.gizzlePending = null;
    throw new Error('Too late — target no longer has one card');
  }

  // Penalty: draw 2
  target.hand.push(drawOne(state));
  target.hand.push(drawOne(state));
  state.gizzlePending = null;
}

export function applyRematch(state: TableState, requesterId: string): void {
  if (state.hostId !== requesterId) throw new Error('Only the host can rematch');
  if (state.players.length === 0) throw new Error('No players at the table');

  // Reset board while keeping the player list.
  state.phase = 'lobby';
  state.deck = [];
  state.discard = [];
  state.currentColor = null;
  state.currentTurn = 0;
  state.direction = 1;
  state.pendingDraw = null;
  state.gizzlePending = null;
  state.winnerId = null;

  for (const p of state.players) {
    p.hand = [];
    p.hasDrawn = false;
  }
}

export function removePlayer(state: TableState, playerId: string): void {
  const idx = state.players.findIndex((p) => p.id === playerId);
  if (idx === -1) return;

  state.players.splice(idx, 1);

  if (state.gizzlePending?.playerId === playerId) {
    state.gizzlePending = null;
  }

  // Fix host
  if (state.hostId === playerId) {
    state.hostId = state.players[0]?.id ?? null;
  }

  // Fix currentTurn index
  if (state.players.length === 0) {
    state.phase = 'lobby';
    state.currentTurn = 0;
    state.pendingDraw = null;
    state.winnerId = null;
    return;
  }

  if (state.phase === 'playing') {
    if (idx < state.currentTurn) state.currentTurn = Math.max(0, state.currentTurn - 1);
    if (state.currentTurn >= state.players.length) state.currentTurn = 0;

    // If only one player remains, they win
    if (state.players.length === 1) {
      state.phase = 'finished';
      state.winnerId = state.players[0].id;
    }
  }
}
