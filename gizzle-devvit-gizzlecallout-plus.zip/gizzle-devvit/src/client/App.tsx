import React, { useEffect, useMemo, useRef, useState } from 'react';
import { connectRealtime, context, showToast } from '@devvit/web/client';
import type { Card, Color, PublicTableState, TableSummary } from '../shared/types';

type View =
  | { screen: 'lobby' }
  | { screen: 'table'; tableId: number };

const COLORS: Color[] = ['red', 'yellow', 'green', 'blue'];

function fmtColor(c: string | null | undefined) {
  if (!c) return '—';
  return c.toUpperCase();
}

async function api<T>(path: string, body?: unknown): Promise<T> {
  const res = await fetch(path, {
    method: body ? 'POST' : 'GET',
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = (data && (data.error || data.message)) || `Request failed: ${res.status}`;
    const err: any = new Error(msg);
    if (res.status === 409) err.code = 'STALE_STATE';
    throw err;
  }
  return data as T;
}

export default function App() {
  const [view, setView] = useState<View>({ screen: 'lobby' });
  const [summaries, setSummaries] = useState<TableSummary[]>([]);
  const [table, setTable] = useState<PublicTableState | null>(null);
  const [loading, setLoading] = useState(false);
  const [chooseColor, setChooseColor] = useState<{ cardId: string; kind: 'W' | 'D4' } | null>(null);
  const [animPlayId, setAnimPlayId] = useState<string | null>(null);
  const [topAnimKey, setTopAnimKey] = useState(0);
  const [now, setNow] = useState(() => Date.now());
  const [winFlash, setWinFlash] = useState<{ winner: string; at: number } | null>(null);
  const [penaltyShake, setPenaltyShake] = useState(false);

  const prevTableRef = useRef<PublicTableState | null>(null);

  const postId = (context as any)?.postId ?? 'unknown-post';

  const currentTableId = view.screen === 'table' ? view.tableId : null;
  const channel = useMemo(() => {
    if (currentTableId === null) return null;
    // Realtime channel names should be simple strings; avoid colons.
    return `gizzle-${postId}-table-${currentTableId}`;
  }, [postId, currentTableId]);

  const refreshLobby = async () => {
    const data = await api<{ tables: TableSummary[] }>('/api/lobby');
    setSummaries(data.tables);
  };

  const refreshTable = async (tableId: number) => {
    const data = await api<PublicTableState>(`/api/table/state?tableId=${tableId}`);
    setTable(data);
  };

  const syncIfStale = async (e: any) => {
    if (e?.code !== 'STALE_STATE') return false;
    if (view.screen === 'table') {
      await Promise.all([
        refreshTable(view.tableId).catch(() => undefined),
        refreshLobby().catch(() => undefined),
      ]);
    } else {
      await refreshLobby().catch(() => undefined);
    }
    showToast('Synced to latest table state');
    return true;
  };

  useEffect(() => {
    refreshLobby().catch((e) => {
      console.error(e);
      showToast(`Lobby error: ${e.message}`);
    });
  }, []);

  useEffect(() => {
    if (view.screen !== 'table') {
      setTable(null);
      return;
    }

    let rt: any | null = null;
    let cancelled = false;

    (async () => {
      try {
        await refreshTable(view.tableId);
        rt = await connectRealtime({ channel: channel! });
        rt.on('message', async (msg: any) => {
          if (cancelled) return;
          if (msg?.data?.type === 'table-updated' && msg?.data?.tableId === view.tableId) {
            await refreshTable(view.tableId);
            await refreshLobby();
          }
        });
      } catch (e: any) {
        console.error(e);
        showToast(`Realtime error: ${e.message}. Falling back to polling.`);
        // Fallback polling
        const timer = setInterval(() => {
          refreshTable(view.tableId).catch(() => undefined);
          refreshLobby().catch(() => undefined);
        }, 1200);
        return () => clearInterval(timer);
      }
    })();

    return () => {
      cancelled = true;
      try { rt?.disconnect?.(); } catch {}
    };
  }, [view, channel]);

  const join = async (tableId: number) => {
    setLoading(true);
    try {
      await api('/api/table/join', { tableId });
      await refreshLobby();
      setView({ screen: 'table', tableId });
      showToast('Joined table');
    } catch (e: any) {
      showToast(e.message);
    } finally {
      setLoading(false);
    }
  };

  const leave = async () => {
    if (view.screen !== 'table') return;
    setLoading(true);
    try {
      await api('/api/table/leave', { tableId: view.tableId, expectedVersion: table?.version });
      showToast('Left table');
      setView({ screen: 'lobby' });
      await refreshLobby();
    } catch (e: any) {
      if (e?.code === 'STALE_STATE') {
        showToast('Synced to latest state. Try again.');
        await refreshLobby().catch(() => undefined);
      } else {
        showToast(e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const start = async () => {
    if (view.screen !== 'table') return;
    setLoading(true);
    try {
      await api('/api/table/start', { tableId: view.tableId, expectedVersion: table?.version });
      await refreshTable(view.tableId);
      await refreshLobby();
    } catch (e: any) {
      if (e?.code === 'STALE_STATE') {
        showToast('Synced to latest state. Try again.');
        await refreshTable(view.tableId).catch(() => undefined);
        await refreshLobby().catch(() => undefined);
      } else {
        showToast(e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const draw = async () => {
    if (view.screen !== 'table') return;
    setLoading(true);
    try {
      await api('/api/table/draw', { tableId: view.tableId, expectedVersion: table?.version });
      await refreshTable(view.tableId);
      await refreshLobby();
    } catch (e: any) {
      if (e?.code === 'STALE_STATE') {
        showToast('Synced to latest state. Try again.');
        await refreshTable(view.tableId).catch(() => undefined);
        await refreshLobby().catch(() => undefined);
      } else {
        showToast(e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const pass = async () => {
    if (view.screen !== 'table') return;
    setLoading(true);
    try {
      await api('/api/table/pass', { tableId: view.tableId, expectedVersion: table?.version });
      await refreshTable(view.tableId);
      await refreshLobby();
    } catch (e: any) {
      if (e?.code === 'STALE_STATE') {
        showToast('Synced to latest state. Try again.');
        await refreshTable(view.tableId).catch(() => undefined);
        await refreshLobby().catch(() => undefined);
      } else {
        showToast(e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const callGizzle = async () => {
    if (view.screen !== 'table') return;
    setLoading(true);
    try {
      await api('/api/table/gizzle/call', { tableId: view.tableId, expectedVersion: table?.version });
      showToast('GIZZLE!');
      await refreshTable(view.tableId);
      await refreshLobby();
    } catch (e: any) {
      if (e?.code === 'STALE_STATE') {
        showToast('Synced to latest state. Try again.');
        await refreshTable(view.tableId).catch(() => undefined);
        await refreshLobby().catch(() => undefined);
      } else {
        showToast(e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const catchGizzle = async () => {
    if (view.screen !== 'table') return;
    setLoading(true);
    try {
      await api('/api/table/gizzle/catch', { tableId: view.tableId, expectedVersion: table?.version });
      showToast('Caught! +2 penalty applied.');
      await refreshTable(view.tableId);
      await refreshLobby();
    } catch (e: any) {
      if (e?.code === 'STALE_STATE') {
        showToast('Synced to latest state. Try again.');
        await refreshTable(view.tableId).catch(() => undefined);
        await refreshLobby().catch(() => undefined);
      } else {
        showToast(e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const rematch = async () => {
    if (view.screen !== 'table') return;
    setLoading(true);
    try {
      await api('/api/table/rematch', { tableId: view.tableId, expectedVersion: table?.version });
      showToast('Rematch ready');
      await refreshTable(view.tableId);
      await refreshLobby();
    } catch (e: any) {
      if (e?.code === 'STALE_STATE') {
        showToast('Synced to latest state. Try again.');
        await refreshTable(view.tableId).catch(() => undefined);
        await refreshLobby().catch(() => undefined);
      } else {
        showToast(e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const playCard = async (card: Card) => {
    if (view.screen !== 'table') return;

    if (card.kind === 'W' || card.kind === 'D4') {
      setChooseColor({ cardId: card.id, kind: card.kind });
      return;
    }

    setAnimPlayId(card.id);
    setTimeout(() => setAnimPlayId(null), 260);
    setLoading(true);
    try {
      await api('/api/table/play', { tableId: view.tableId, cardId: card.id, expectedVersion: table?.version });
      await refreshTable(view.tableId);
      await refreshLobby();
    } catch (e: any) {
      if (e?.code === 'STALE_STATE') {
        showToast('Synced to latest state. Try again.');
        await refreshTable(view.tableId).catch(() => undefined);
        await refreshLobby().catch(() => undefined);
      } else {
        showToast(e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const confirmWild = async (color: Color) => {
    if (view.screen !== 'table' || !chooseColor) return;
    setLoading(true);
    try {
      setAnimPlayId(chooseColor.cardId);
      setTimeout(() => setAnimPlayId(null), 260);
      await api('/api/table/play', {
        tableId: view.tableId,
        cardId: chooseColor.cardId,
        chooseColor: color,
        expectedVersion: table?.version,
      });
      setChooseColor(null);
      await refreshTable(view.tableId);
      await refreshLobby();
    } catch (e: any) {
      if (e?.code === 'STALE_STATE') {
        showToast('Synced to latest state. Try again.');
        await refreshTable(view.tableId).catch(() => undefined);
        await refreshLobby().catch(() => undefined);
      } else {
        showToast(e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  // Tick while a GIZZLE callout is pending (for “pending for Xs” UI).
  useEffect(() => {
    if (!table?.gizzlePending) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [table?.gizzlePending?.playerId, table?.gizzlePending?.createdAt]);

  // Simple “win flash” overlay for a nicer finish.
  useEffect(() => {
    if (!table) return;
    if (table.phase === 'finished' && table.winnerName) {
      setWinFlash({ winner: table.winnerName, at: Date.now() });
      const to = setTimeout(() => setWinFlash(null), 3800);
      return () => clearTimeout(to);
    }
  }, [table?.phase, table?.winnerName]);

  // Keyboard shortcuts (table view): D=draw, P=pass, G=call, C=catch, R=start/rematch
  useEffect(() => {
    if (view.screen !== 'table' || !table) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const k = e.key.toLowerCase();
      if (k === 'd' && table.canDraw && !loading) {
        e.preventDefault();
        draw();
      }
      if (k === 'p' && table.canPass && !loading) {
        e.preventDefault();
        pass();
      }
      if (k === 'g' && table.canCallGizzle && !loading) {
        e.preventDefault();
        callGizzle();
      }
      if (k === 'c' && table.canCatchGizzle && !loading) {
        e.preventDefault();
        catchGizzle();
      }
      if (k === 'r' && !loading) {
        if (table.phase === 'lobby' && table.canStart) {
          e.preventDefault();
          start();
        }
        if (table.phase === 'finished' && table.canRematch) {
          e.preventDefault();
          rematch();
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view.screen, table?.tableId, table?.phase, table?.canDraw, table?.canPass, table?.canCallGizzle, table?.canCatchGizzle, table?.canStart, table?.canRematch, loading]);

  // Reactive UX: toasts + small shake animations when key game events happen.
  useEffect(() => {
    if (!table) return;

    const prev = prevTableRef.current;
    if (!prev) {
      prevTableRef.current = table;
      return;
    }

    if (table.version !== prev.version) {
      // Phase transitions
      if (prev.phase === 'lobby' && table.phase === 'playing') {
        showToast('Game started!');
      }
      if (prev.phase !== 'finished' && table.phase === 'finished' && table.winnerName) {
        showToast(`Winner: ${table.winnerName}`);
      }

      // Pending draw changes (stack building)
      const prevPenalty = prev.pendingDraw ? `${prev.pendingDraw.type}:${prev.pendingDraw.count}` : 'none';
      const newPenalty = table.pendingDraw ? `${table.pendingDraw.type}:${table.pendingDraw.count}` : 'none';
      if (prevPenalty !== newPenalty && table.pendingDraw) {
        showToast(`Penalty stack: ${table.pendingDraw.type} × ${table.pendingDraw.count}`);
        setPenaltyShake(true);
        window.setTimeout(() => setPenaltyShake(false), 260);
      }

      // GIZZLE callout changes
      if (!prev.gizzlePending && table.gizzlePending) {
        if (table.canCallGizzle) {
          showToast('You have 1 card — hit GIZZLE!');
        } else if (table.canCatchGizzle) {
          showToast(`Catch ${table.gizzlePending.playerName} for +2!`);
        }
      }
    }

    prevTableRef.current = table;
  }, [table?.version]);

  // Animate the discard pile whenever the top changes.
  useEffect(() => {
    if (!table) return;
    setTopAnimKey((k) => k + 1);
  }, [table?.topCardLabel, table?.currentColor]);

  if (view.screen === 'lobby') {
    return (
      <div className="container">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div>
            <p className="h1">GIZZLE</p>
            <p className="muted" style={{ marginTop: 4 }}>
              Two tables · up to 4 players each · Draw2 stacks only on Draw2, Draw4 stacks only on Draw4.
              <br />
              Draw 4 fairness: you can only play Draw 4 if you have no card matching the current color.
              <br />
              GIZZLE callout: if you end a play with 1 card, hit <strong>GIZZLE</strong> before the next player acts (or they can catch you for +2).
            </p>
          </div>
          <button onClick={() => refreshLobby()} disabled={loading}>
            Refresh
          </button>
        </div>

        <div style={{ height: 10 }} />

        <div className="row" style={{ gap: 12, alignItems: 'stretch' }}>
          {summaries.map((t) => (
            <div key={t.tableId} className="card" style={{ flex: 1 }}>
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <div>
                  <div className="row" style={{ gap: 8 }}>
                    <span className="badge">Table {t.tableId + 1}</span>
                    <span className="badge">{t.phase}</span>
                  </div>
                  <div className="muted" style={{ marginTop: 8 }}>
                    Players: {t.playerCount}/4
                  </div>
                </div>
                <div className="row" style={{ gap: 8 }}>
                  <button
                    onClick={() => setView({ screen: 'table', tableId: t.tableId })}
                    disabled={loading}
                    title="View as spectator"
                  >
                    View
                  </button>
                  <button
                    onClick={() => join(t.tableId)}
                    disabled={loading || t.playerCount >= 4 || t.phase !== 'lobby'}
                    title={
                      t.phase !== 'lobby'
                        ? 'Game in progress — view to spectate'
                        : t.playerCount >= 4
                          ? 'Table full'
                          : 'Join'
                    }
                  >
                    Join
                  </button>
                </div>
              </div>

              {t.phase === 'playing' && (
                <div className="small muted" style={{ marginTop: 10 }}>
                  Current color: {fmtColor(t.currentColor)} · Top: {t.topCardLabel || '—'}
                </div>
              )}

              {t.phase === 'finished' && t.winnerName && (
                <div className="small" style={{ marginTop: 10 }}>
                  Winner: <strong>{t.winnerName}</strong>
                </div>
              )}
            </div>
          ))}
        </div>

        <div style={{ marginTop: 'auto' }} className="small muted">
          Running inside Devvit Web.
        </div>
      </div>
    );
  }

  // Table view
  if (!table) {
    return (
      <div className="container">
        <p className="h1">Loading…</p>
      </div>
    );
  }

  const you = table.you;
  const isYourTurn = table.currentPlayerId === you?.id;
  const gizzleAgeSec = table.gizzlePending
    ? Math.max(0, Math.floor((now - table.gizzlePending.createdAt) / 1000))
    : 0;

  const handSorted = [...table.yourHand].sort((a, b) => {
    const colorOrder = (c: string | null) => {
      if (c === 'red') return 0;
      if (c === 'yellow') return 1;
      if (c === 'green') return 2;
      if (c === 'blue') return 3;
      return 4; // wilds
    };
    const ka = colorOrder(a.color);
    const kb = colorOrder(b.color);
    if (ka !== kb) return ka - kb;

    // numbers first, then actions, then wilds
    const kindOrder = (k: string) => {
      if (k === 'N') return 0;
      if (k === 'S') return 1;
      if (k === 'R') return 2;
      if (k === 'D2') return 3;
      if (k === 'W') return 4;
      if (k === 'D4') return 5;
      return 9;
    };
    const oa = kindOrder(a.kind);
    const ob = kindOrder(b.kind);
    if (oa !== ob) return oa - ob;

    // numeric ordering for numbers
    if (a.kind === 'N' && b.kind === 'N') return (a.value ?? 0) - (b.value ?? 0);
    return a.label.localeCompare(b.label);
  });

  return (
    <div className="container">
      {winFlash && (
        <div className="winOverlay" aria-live="polite">
          <div className="winConfetti" />
          <div className="winPanel">
            <div className="winTitle">🎉 {winFlash.winner} wins!</div>
            <div className="small muted" style={{ marginTop: 6 }}>
              Shortcut: press <b>R</b> for {table.canRematch ? 'Rematch' : 'nothing'}.
            </div>
          </div>
        </div>
      )}
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div>
          <p className="h1">
            Table {table.tableId + 1} <span className="badge">{table.phase}</span>
          </p>
          <div className="small muted" style={{ marginTop: 6 }}>
            {table.phase !== 'lobby' ? (
              <>
                Color: {fmtColor(table.currentColor)} · Top: {table.topCardLabel || '—'}
                {table.pendingDraw && (
                  <> · Pending {table.pendingDraw.type} × {table.pendingDraw.count}</>
                )}
              </>
            ) : (
              <>Pick a seat by joining. Host can start at 2–4 players.</>
            )}
          </div>
        </div>

        <div className="row">
          {table.you ? (
            <button onClick={leave} disabled={loading}>
              Leave
            </button>
          ) : table.phase === 'lobby' && table.players.length < 4 ? (
            <button onClick={() => join(table.tableId)} disabled={loading}>
              Join
            </button>
          ) : (
            <span className="badge" title="You are spectating">Spectating</span>
          )}
          <button onClick={() => refreshTable(table.tableId)} disabled={loading}>
            Refresh
          </button>
        </div>
      </div>

      <div style={{ height: 10 }} />

      {table.phase !== 'lobby' && (
        <div className="board">
          <div className="pile">
            <div
              key={`${topAnimKey}-${table.topCardLabel ?? 'none'}`}
              className={`pileCard ${penaltyShake ? 'penaltyShake' : ''} ${table.currentColor ? `c-${table.currentColor}` : 'c-wild'}`}
              title={table.topCardLabel ?? '—'}
            >
              <div className="pileLabel">{table.topCardLabel ?? '—'}</div>
              {table.pendingDraw && (
                <div className="pileSub">
                  Stack: {table.pendingDraw.type} · {table.pendingDraw.count}
                </div>
              )}
            </div>
          </div>

          <div className="boardInfo">
            <div className="row" style={{ flexWrap: 'wrap' }}>
              <span className="badge">Turn: {table.currentPlayerName ?? '—'}</span>
              {isYourTurn ? <span className="badge">Your turn</span> : null}
              {table.pendingDraw ? (
                <span className="badge" title="A draw penalty is pending. You may only stack the same draw type.">
                  Pending {table.pendingDraw.type}
                </span>
              ) : null}
              {table.gizzlePending ? (
                <span className="badge" title="Someone ended a play with 1 card. Call GIZZLE or get caught for +2.">
                  GIZZLE: {table.gizzlePending.playerName} · {gizzleAgeSec}s
                </span>
              ) : null}
            </div>
            <div className="small muted" style={{ marginTop: 8 }}>
              Tips: stacking is same-type only (no mixing). Draw 4 is only legal if you have no card matching the current color.
            </div>
          </div>
        </div>
      )}

      {table.phase === 'playing' && table.canCallGizzle && (
        <div className="calloutOverlay" aria-live="polite">
          <div className="calloutPanel">
            <div className="calloutTitle">You have 1 card</div>
            <div className="calloutHint">
              Hit <b>GIZZLE</b> before the next player acts. <span className="muted">({gizzleAgeSec}s)</span>
              <div className="small muted" style={{ marginTop: 6 }}>Shortcut: press <b>G</b></div>
            </div>
            <button className="gizzleBtn big" onClick={callGizzle} disabled={loading}>
              GIZZLE!
            </button>
          </div>
        </div>
      )}

      {table.phase === 'playing' && table.canCatchGizzle && table.gizzlePending && (
        <div className="calloutOverlay" aria-live="polite">
          <div className="calloutPanel">
            <div className="calloutTitle">GIZZLE window</div>
            <div className="calloutHint">
              <b>{table.gizzlePending.playerName}</b> is at 1 card. Catch them before the next action for <b>+2</b>.
              <div className="small muted" style={{ marginTop: 6 }}>
                Open for {gizzleAgeSec}s · Shortcut: press <b>C</b>
              </div>
            </div>
            <button className="catchBtn big" onClick={catchGizzle} disabled={loading}>
              Catch GIZZLE
            </button>
          </div>
        </div>
      )}

      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div className="row" style={{ flexWrap: 'wrap' }}>
            {table.players.map((p) => (
              <span
                key={p.id}
                className={`badge ${p.id === table.currentPlayerId ? 'turn' : ''}`}
                style={{ opacity: p.id === table.currentPlayerId ? 1 : 0.75 }}
              >
                {p.name} · {p.handCount}
                {p.id === table.hostId ? ' · host' : ''}
                {p.id === table.currentPlayerId ? ' · turn' : ''}
              </span>
            ))}
          </div>
          {table.phase === 'lobby' && (
            <button onClick={start} disabled={loading || !table.canStart}>
              Start
            </button>
          )}
          {table.phase === 'finished' && (
            <button onClick={rematch} disabled={loading || !table.canRematch}>
              Rematch
            </button>
          )}
          {table.phase === 'finished' && table.winnerName && (
            <span className="badge">Winner: {table.winnerName}</span>
          )}
        </div>

        {table.phase === 'lobby' && (
          <div className="small muted" style={{ marginTop: 10 }}>
            Waiting for host to start (need 2-4 players).
          </div>
        )}

        {table.phase === 'playing' && (
          <div style={{ marginTop: 10 }} className="row">
            <button onClick={draw} disabled={loading || !table.canDraw}>
              {table.pendingDraw ? `Draw ${table.pendingDraw.count}` : 'Draw'}
            </button>
            <button onClick={pass} disabled={loading || !table.canPass}>
              Pass
            </button>
            {table.gizzlePending && (
              <span className="badge" title="Someone has 1 card and must call GIZZLE before the next action">
                GIZZLE pending: {table.gizzlePending.playerName}
              </span>
            )}
            {table.canCallGizzle && (
              <button className="gizzleBtn" onClick={callGizzle} disabled={loading}>
                GIZZLE!
              </button>
            )}
            {table.canCatchGizzle && (
              <button className="catchBtn" onClick={catchGizzle} disabled={loading}>
                Catch GIZZLE
              </button>
            )}
            <span className="small muted">
              {isYourTurn ? 'Your turn.' : `Waiting for ${table.currentPlayerName}…`}
            </span>
          </div>
        )}
      </div>

      <div className="card" style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div>
            <strong>Your hand</strong> {you ? <span className="muted">({you.handCount})</span> : null}
          </div>
          <span className="small muted">Click a highlighted card to play.</span>
        </div>

        <div style={{ height: 8 }} />

        <div className="hand">
          {handSorted.map((c) => {
            const playable = table.playableCardIds.includes(c.id);
            const colorClass = c.color ? `c-${c.color}` : 'c-wild';
            const kindClass = `k-${c.kind}`;
            const animClass = animPlayId === c.id ? 'playedOut' : '';
            return (
              <div
                key={c.id}
                className={`playCard ${colorClass} ${kindClass} ${animClass} ${playable ? 'playable' : 'disabled'}`}
                role="button"
                tabIndex={0}
                onClick={() => playable && playCard(c)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && playable) playCard(c);
                }}
                title={playable ? 'Play' : 'Not playable'}
              >
                <div className="small muted">{c.color ?? 'wild'}</div>
                <div style={{ fontWeight: 800, fontSize: 18 }}>{c.label}</div>
              </div>
            );
          })}
        </div>
      </div>

      {chooseColor && (
        <div className="modalBackdrop" onClick={() => !loading && setChooseColor(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Choose a color</h3>
            <div className="row" style={{ flexWrap: 'wrap' }}>
              {COLORS.map((c) => (
                <button key={c} className="colorBtn" onClick={() => confirmWild(c)} disabled={loading}>
                  {c.toUpperCase()}
                </button>
              ))}
            </div>
            <div className="small muted" style={{ marginTop: 10 }}>
              Applies to {chooseColor.kind === 'W' ? 'Wild' : 'Wild Draw Four'}.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
