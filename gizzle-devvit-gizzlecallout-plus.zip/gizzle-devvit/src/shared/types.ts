export type Color = 'red' | 'yellow' | 'green' | 'blue';

export type CardKind =
  | 'N'   // number
  | 'S'   // skip
  | 'R'   // reverse
  | 'D2'  // draw two
  | 'W'   // wild
  | 'D4'; // wild draw four

export type Card = {
  id: string;
  kind: CardKind;
  color: Color | null;
  value: number | null; // only for numbers
  label: string; // UI label
};

export type PendingDraw = {
  type: 'D2' | 'D4';
  count: number;
};

export type GizzlePending = {
  playerId: string;
  playerName: string;
  createdAt: number;
};

export type Player = {
  id: string;
  name: string;
  hand: Card[];
  hasDrawn: boolean;
};

export type TablePhase = 'lobby' | 'playing' | 'finished';

export type TableState = {
  tableId: number;
  phase: TablePhase;
  hostId: string | null;
  players: Player[];

  deck: Card[];
  discard: Card[];
  currentColor: Color | null;
  currentTurn: number; // index in players
  direction: 1 | -1;
  pendingDraw: PendingDraw | null;

  // GIZZLE callout (UNO-style): set when a player ends their play with exactly 1 card.
  // The player should call GIZZLE before the next player takes an action.
  // Another player can "catch" them before that action; if caught, the target draws 2.
  gizzlePending: GizzlePending | null;

  winnerId: string | null;
  version: number;
  updatedAt: number;
};

export type PublicPlayer = {
  id: string;
  name: string;
  handCount: number;
};

export type PublicTableState = {
  tableId: number;
  phase: TablePhase;
  hostId: string | null;
  players: PublicPlayer[];
  currentColor: Color | null;
  topCardLabel: string | null;
  pendingDraw: PendingDraw | null;
  gizzlePending: GizzlePending | null;
  currentPlayerId: string | null;
  currentPlayerName: string | null;

  you: PublicPlayer | null;
  yourHand: Card[];
  playableCardIds: string[];
  canDraw: boolean;
  canPass: boolean;
  canCallGizzle: boolean;
  canCatchGizzle: boolean;
  canStart: boolean;
  canRematch: boolean;

  winnerName: string | null;

  // Used by the client to detect changes and produce smooth UX (toasts/animations).
  version: number;
  updatedAt: number;
};

export type TableSummary = {
  tableId: number;
  phase: TablePhase;
  playerCount: number;
  currentColor: Color | null;
  topCardLabel: string | null;
  winnerName: string | null;

  version: number;
  updatedAt: number;
};
